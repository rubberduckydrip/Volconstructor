package com.example.dynamiccode;

import android.util.Log;
import android.widget.Toast;

public class StringFns {
    static String TAG = "DYNAMIC_CODE_LOADING_EXAMPLE";
    public static String password = "pass2-NnJhj34b4";

    public static int countLetters(String str) {
        Log.i(TAG, password);
        return str.length();
    }
}
